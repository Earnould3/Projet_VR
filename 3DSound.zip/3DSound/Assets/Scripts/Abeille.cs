using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Abeille : MonoBehaviour
{
    public GameObject joueur;
    public float speed = 1;
    public float dist = 3;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float x = Mathf.Sin(Time.time * speed) * dist;
        float z = Mathf.Cos(Time.time * speed) * dist;
        transform.position = new Vector3(joueur.transform.position.x + x, joueur.transform.position.y + 2, joueur.transform.position.z + z);
    }
}
